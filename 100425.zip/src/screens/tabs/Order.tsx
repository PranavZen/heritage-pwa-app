import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { hooks } from '../../hooks';
import { items } from '../../items';
import { Routes } from '../../routes';
import { RootState } from '../../store';
import type { DishType } from '../../types';
import { components } from '../../components';
import { MenuType } from '../../types/MenuType';
import axios from 'axios';
import { notification } from 'antd';
import { SubscriptionOrder } from './SubscriptionOrder';

export const Order: React.FC = () => {
  const dispatch = hooks.useDispatch();
  const [opacity, setOpacity] = useState<number>(0);
  const [totalPrice, SetTotalPrice] = useState<any[]>([]);
  const [addressId, SetAddressId] = useState('');
  const [loading, setLoading] = useState(false);

  hooks.useScrollToTop();
  hooks.useOpacity(setOpacity);
  hooks.useThemeColor('#F6F9F9', '#F6F9F9', dispatch);

  const navigate = hooks.useNavigate();

  const c_id = localStorage.getItem('c_id');
  const cityId = localStorage.getItem('cityId');

  useEffect(() => {
    const getAddToCartData = async () => {
      const formData = new FormData();
      formData.append('city_id', cityId || '');
      formData.append('c_id', c_id || '');
      formData.append('next_id', '0');
      try {
        const response = await axios.post(
          `https://heritage.bizdel.in/app/consumer/services_v11/getCartData`,
          formData
        );

        SetTotalPrice(response.data.optionListing);
      } catch (error) {
        console.error(error);
      }
    };
    getAddToCartData();
  }, [cityId, c_id]);

  useEffect(() => {
    const getAddress = async () => {
      const formData = new FormData();
      formData.append('c_id', c_id || '');
      try {
        const response = await axios.post(
          `https://heritage.bizdel.in/app/consumer/services_v11/getAllAddressById`,
          formData
        );

        SetAddressId(response.data.addresses[0].id);
      } catch (error) {
        console.error(error);
      }
    };
    getAddress();
  }, [c_id]);

  const handleCheckout = async () => {
    setLoading(true);
    const formData = new FormData();
    formData.append('c_id', c_id || '');
    formData.append('addresses_id', String(addressId) || '');

    try {
      const response = await axios.post(
        `https://heritage.bizdel.in/app/consumer/services_v11/placeOrder`,
        formData
      );

      setLoading(false);

      if (response.data.status === 'success') {
        notification.success({ message: response.data.message });
        setTimeout(() => {
          window.location.reload();
        }, 1000);
      } else if (response.data.status === 'fail') {
        notification.error({ message: response.data.message || 'Order placement failed' });
      }
    } catch (error) {
      setLoading(false);
      console.error(error);
      notification.error({ message: 'An error occurred while placing your order.' });
    }
  };

  useEffect(() => {
    handleCheckout();
  }, []);

  const { menuLoading, menu } = hooks.useGetMenu();

  const { list, subtotal, delivery, total } = useSelector(
    (state: RootState) => state.cartSlice
  );

  const renderDishes = (): JSX.Element => {
    return (
      <section style={{ marginBottom: 20 }}>
        <ul style={{ paddingTop: 10 }}>
          {totalPrice.map((dish: DishType, index: number, array: DishType[]) => {
            const isLast = index === array.length - 1;
            return (
              <items.OrderItem
                key={dish.id}
                dish={dish}
                isLast={isLast}
              />
            );
          })}
        </ul>
      </section>
    );
  };

  const renderSummary = (): JSX.Element => {
    return (
      <section
        style={{
          padding: 20,
          borderRadius: 10,
          marginBottom: 20,
          border: '1px solid var(--main-turquoise)',
        }}
      >
        <div className='row-center-space-between' style={{ marginBottom: 13 }}>
          <span
            className='t14'
            style={{ color: 'var(--main-color)', fontWeight: 500 }}
          >
            Subtotal
          </span>
          <span className='t14' style={{ color: 'var(--main-color)' }}>
            ₹{' '}
            {totalPrice.reduce((total, elem) => {
              return total + elem.quantity * elem.price * (elem.no_of_deliveries === '0' ? '1' : elem.no_of_deliveries);
            }, 0).toFixed(2)}
          </span>
        </div>
        <div
          className='row-center-space-between'
          style={{
            paddingBottom: 13,
            marginBottom: 20,
            borderBottom: '1px solid #DBE9F5',
          }}
        >
          <span className='t14'>Delivery charges</span>
          <span className='t14'>₹{delivery}</span>
        </div>
        <div className='row-center-space-between'>
          <h4>Total</h4>
          <h4>
            ₹{' '}
            {totalPrice.reduce((total, elem) => {
              return total + elem.quantity * elem.price * (elem.no_of_deliveries === '0' ? '1' : elem.no_of_deliveries);
            }, 0).toFixed(2)}
          </h4>
        </div>
      </section>
    );
  };

  const renderButton = (): JSX.Element => {
    return (
      <components.Button
        text='Checkout'
        onClick={handleCheckout}
      />
    );
  };

  const renderContent = (): JSX.Element | null => {
    if (totalPrice.length === 0 && !menuLoading) return null;
    return (
      <main className='container scrollable'>
        {renderDishes()}
        {renderSummary()}
        {renderButton()}
      </main>
    );
  };

  const renderEmpty = (): JSX.Element | null => {
    if (totalPrice.length === 0 && !menuLoading ) {
      return (
        <main className='scrollable'>
          <SubscriptionOrder/>
        </main>
      );
    }
  
    return null;
  };

  const renderLoading = (): JSX.Element | null => {
    if (loading || menuLoading) return <components.Loader />;
    return null;
  };

  return (
    <div id='screen' style={{ opacity }}>
      {renderEmpty()}
      {renderContent()}
      {renderLoading()}
      
    </div>
  );
};

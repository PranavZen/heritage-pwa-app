export type DishType = {
  id?: number;
  name?: string;
  kcal?: string;
  image?: string;
  price?: string;
  weight?: string;
  isNew?: boolean;
  isHot?: boolean;
  menu: string[];
  quantity?: number;
  description?: string;
  dietaryPreferences?: string[];
  optionListing:string[];
  option_value_image:string;
  product_name:string;
  cart_id:number;
  
cart_quantity:number;
product_id:number;
option_value_id:Number;
option_name:string;
option_value_name:string;
brand_name:string;
};

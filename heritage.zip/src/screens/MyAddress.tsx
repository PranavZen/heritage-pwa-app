import React, { useState, useEffect } from 'react';
import { hooks } from '../hooks';
import { Routes } from '../routes';
import { components } from '../components';
import axios from 'axios';

export const MyAddress: React.FC = () => {
  const dispatch = hooks.useDispatch();
  const navigate = hooks.useNavigate();

  const [loading, setLoading] = useState<boolean>(false);
  const [addresses, setAddresses] = useState<any[]>([]);
  const [opacity, setOpacity] = useState<number>(0);
  const [openAccordions, setOpenAccordions] = useState<Set<string>>(new Set());

  console.log("addressesaddressesqqwqwq", addresses);


  hooks.useScrollToTop();
  hooks.useOpacity(setOpacity);
  hooks.useThemeColor('#F6F9F9', '#F6F9F9', dispatch);


  const c_id = localStorage.getItem('c_id');

  useEffect(() => {
    const fetchAddresses = async () => {
      const formData = new FormData();
      formData.append('c_id', c_id || 'null');
      try {
        setLoading(true);
        const response = await axios.post('https://heritage.bizdel.in/app/consumer/services_v11/getAllAddressById', formData);
        setAddresses(response.data.addresses);
        console.log("responseresponse", response.data.addresses);
        setLoading(false);
      } catch (error) {
        setLoading(false);
        console.error('Error fetching addresses:', error);
      }
    };

    fetchAddresses();
  }, [c_id]);

  const movetoAddressAddPage = () => {
    navigate(Routes.AddressAdd);
  };

  const handleToggle = (id: number) => {
    setOpenAccordions((prev) => {
      const newSet = new Set(prev);
      const idStr = id.toString();
      if (newSet.has(idStr)) {
        newSet.delete(idStr);
      } else {
        newSet.add(idStr);
      }
      return newSet;
    });
  };

  const renderHeader = (): JSX.Element => {
    return (
      <components.Header
        title="My Addresses"
        showGoBack={true}
      />
    );
  };

  const renderContent = (): JSX.Element => {
    if (loading) return <components.Loader />;

    return (
      <main className="scrollable container">
        <section
          className="accordion"
          style={{ paddingTop: 10 }}
        >
          <div
            style={{
              borderRadius: 10,
              marginBottom: 10,
              border: '1px solid red',
              backgroundColor: 'var(--white-color)',
              padding: 20,
            }}
          >
            <p>

              {
                addresses.length === 0 ? (
                  <p>Add your Address</p>
                ) : (
                  addresses.map((elem) => {
                    return (
                      <div key={elem.id}> 
                        <h3>{elem.firstname} {elem.lastname}</h3>
                        <p>{elem.flat_plot_no} {elem.wing} {elem.building_name}, {elem.address1} {elem.address2},
                          {elem.area_name}, {elem.city_name}, {elem.state_name} {elem.pincode}
                        </p>
                      </div>
                    );
                  })
                )
              }


            </p>
          </div>



          {/* New Address Section */}
          <div
            onClick={movetoAddressAddPage}
            style={{
              borderRadius: 10,
              marginBottom: 10,
              border: '1px solid red',
              backgroundColor: 'var(--white-color)',
              padding: 20,
            }}
          >
            <p style={{ fontSize: '18px', fontWeight: "600", color: "green" }}>
              New Address
            </p>
          </div>
        </section>
      </main>
    );
  };

  return (
    <div
      id="screen"
      style={{ opacity }}
    >
      {renderHeader()}
      {renderContent()}
    </div>
  );
};

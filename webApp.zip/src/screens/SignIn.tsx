import React, { useState } from 'react';
import axios from 'axios';
import { hooks } from '../hooks';
import { Routes } from '../routes';
import { svg } from '../assets/svg';
import { Input } from '../components/Input';
import { components } from '../components';
import { notification } from 'antd';

export const SignIn: React.FC = () => {
  const dispatch = hooks.useDispatch();
  const navigate = hooks.useNavigate();

  const [rememberMe, setRememberMe] = useState<boolean>(false);
  const [opacity, setOpacity] = useState<number>(0);
  const [mobile, setMobile] = useState<string>('');
  const [otp, setOtp] = useState<string>('');
  const [isOtpSent, setIsOtpSent] = useState<boolean>(false);

  // console.log("mobileeeeeeeeeee", mobile);

  hooks.useScrollToTop();
  hooks.useOpacity(setOpacity);
  hooks.useThemeColor('#F6F9F9', '#F6F9F9', dispatch);

  const handleLogin = async () => {
    if (mobile.length === 10) {
      try {
        const formData = new FormData();
        formData.append('mobile', mobile);

        const response = await axios.post('https://heritage.bizdel.in/app/consumer/services_v11/login', formData);

        if (response.data.status === 'success' && response.data.action === 'existing user') {
          setIsOtpSent(true);
          notification.success({
            message: response.data.message || 'OTP sent to your mobile number',
            placement: 'bottomRight',
          });
          notification.success({
            message: 'OTP sent to your mobile number',
            placement: 'bottomRight',
          });
        } else {
          notification.error({
            message: response.data.message || 'Failed to send OTP',
            placement: 'bottomRight',
          });
        }
      } catch (error) {
        console.error('Error during login:', error);
        notification.error({ message: 'Something went wrong. Please try again.' });
      }
    } else {
    
      notification.error({
        message: 'Please enter a valid 10-digit mobile number.',
        placement: 'bottomRight',
      });
    }
  };


  const handleVerifyOtp = async () => {
    try {
      const formData = new FormData();
      formData.append('mobile', mobile);
      formData.append('otp', otp);

      const response = await axios.post(
        'https://heritage.bizdel.in/app/consumer/services_v11/verifyOTP',
        formData
      );

      if (response.data.status === 'success') {
        notification.success({
          message:"OTP Verified Successfull...",
          placement: 'bottomRight',
        });


        localStorage.setItem('userToken', response.data.token);

        navigate(Routes.TabNavigator);
      } else {
        // Display error notification
        notification.error({
          message: response.data.message || 'OTP verification failed',
          placement: 'bottomRight',
        });
      }
    } catch (error) {
      console.error('Error during OTP verification:', error);
      notification.error({
        message: 'Something went wrong. Please try again.',
        placement: 'bottomRight',
      });
    }
  };



  const renderHeader = (): JSX.Element => {
    return <components.Header showGoBack={true} />;
  };

  const renderContent = (): JSX.Element => {
    return (
      <main className="scrollable container">
        <section
          style={{
            backgroundColor: 'var(--white-color)',
            paddingLeft: 20,
            paddingRight: 20,
            height: '100%',
            paddingTop: '22%',
            borderRadius: 10,
          }}
        >
          <h1 style={{ marginBottom: 10 }}>Welcome Back!</h1>
          <span className="t16" style={{ marginBottom: 30, display: 'block' }}>
            {isOtpSent ? 'Enter the OTP sent to your mobile' : 'Sign in to continue'}
          </span>
        
          <Input
            type="number"
            placeholder="Mobile Number"
            containerStyle={{ marginBottom: 14 }}
            leftIcon={<svg.PhoneSvg />}
            value={mobile}
            onChange={(e) => {
              const value = e.target.value;
              if (/^\d{0,10}$/.test(value)) {
                setMobile(value);
              }
            }}

          />
          {mobile.length > 0 && mobile.length !== 10 && (
            <span className='t144'>
              Mobile number must be exactly 10 digits.
            </span>
          )}
          <components.Button text="Send OTP" onClick={handleLogin} 
  
          />
          {!isOtpSent ? (
            <></>
          ) : (
            <>
              <Input
                placeholder="OTP"
                containerStyle={{ marginBottom: 14 }}
                leftIcon={<svg.KeySvg />}
                value={otp}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setOtp(e.target.value)}  // otp is now a string
              />
              <components.Button text="Verify OTP" onClick={handleVerifyOtp} />
            </>
          )}
          <div style={{ gap: 4 }} className="row-center">
            <span className="t14">Don’t have an account?</span>
            <span
              className="t14 clickable"
              style={{ color: 'var(--main-turquoise)' }}
              onClick={() => {
                navigate(Routes.SignUp);
              }}
            >
              Sign up.
            </span>
          </div>
        </section>
      </main>
    );
  };

  return (
    <div id="screen" style={{ opacity }}>
      {renderHeader()}
      {renderContent()}
    </div>
  );
};

export type MenuType = {
  id: number;
  name: string;
  image?: string;
  product_cat_id:string;
  banner:string;
  product_id:string;
};
